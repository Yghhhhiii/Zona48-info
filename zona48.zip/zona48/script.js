
// === SHOWROOM API ===
fetch('https://v2.jkt48connect.my.id/api/jkt48/live/showroom?apikey=Wota48')
  .then(res => res.json())
  .then(data => renderSection(data?.data || [], 'showroom', 'Showroom Live'))
  .catch(() => {
    document.getElementById("showroom").innerHTML += "<p>Gagal memuat data Showroom.</p>";
  });

// === YOUTUBE API ===
fetch('https://v2.jkt48connect.my.id/api/jkt48/live/youtube?apikey=Wota48')
  .then(res => res.json())
  .then(data => renderSection(data?.data || [], 'youtube', 'YouTube Live'))
  .catch(() => {
    document.getElementById("youtube").innerHTML += "<p>Gagal memuat data YouTube.</p>";
  });

// === IDN LIVE API ===
fetch('https://v2.jkt48connect.com/api/jkt48/live/idn?apikey=Wota48')
  .then(res => res.json())
  .then(data => renderIDN(data?.data || []))
  .catch(() => {
    document.getElementById("idn").innerHTML += "<p>Gagal memuat data IDN Live.</p>";
  });

function renderSection(list, targetId, label) {
const container = document.getElementById(targetId);
  list.forEach(item => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <h3>item.member_name || '-'</h3>
      <p>{item.title || label}</p>
      <p>🕒 item.start_time || '-'</p>
      <a href="{item.url || item.link}" target="_blank">🔗 Tonton</a>
    `;
    container.appendChild(div);
  });
}

function renderIDN(list) {
  const container = document.getElementById("idn");
  list.forEach(item => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <h3>item.member_name</h3>
      <p>{item.title}</p>
      <p>🕒 item.date_time || '-'</p>
      <a href="{item.url}" target="_blank">🔗 Tonton</a>
    `;
    container.appendChild(div);
  });
}

// === News Theater ===
const newsList = [
  {
    title: "Jadwal Theater 'Cara Meminum Ramune'",
    date: "8 Sep 2025",
    link: "https://jkt48.com/theater/schedule"
  },
  {
    title: "Pengumuman Ulang Tahun Member",
    date: "10 Sep 2025",
    link: "https://jkt48.com/news/detail/id/1543"
  }
];

function renderNews() {
  const container = document.getElementById("news-content");
  newsList.forEach(news => {
    const div = document.createElement("div");div.className = "news-card";
    div.innerHTML = `
      <h3>news.title</h3>
      <p>📅{news.date}</p>
      <a href="${news.link}" target="_blank">🔗 Baca Selengkapnya</a>
    `;
    container.appendChild(div);
  });
}

renderNews();